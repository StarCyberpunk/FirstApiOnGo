package and;
/*
import (
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Person struct {
	FName, SName string
	login        string
	password     string
	role         string
}
type Answer struct {
	person Person
	code   bool
}

var NameDB = "hello.txt"
var Roles = [3]string{"Admin", "User", "Guest"}
var Auth = false
var User Person

func createPerson() Person {
	var person = Person{}
	fmt.Println("Регистрация")
	fmt.Println("Введите имя")
	fmt.Scan(&person.FName)
	fmt.Println("Введите фамилия")
	fmt.Scan(&person.SName)
	for {
		fmt.Println("Введите логин")
		fmt.Scan(&person.login)
		if !haveLogin(person.login) {
			break
		} else {
			fmt.Println("Логин занят")
		}
	}

	fmt.Println("Введите пароль")
	fmt.Scan(&person.password)
	fmt.Println("Введите номер роли")
	for i := 0; i < len(Roles); i++ {
		s2 := strconv.Itoa(i + 1)
		fmt.Println(s2 + ")" + Roles[i])
	}
	var ii int
	fmt.Fscan(os.Stdin, &ii)
	person.role = Roles[ii-1]
	return person
}
func haveLogin(login string) bool {
	file, err := os.Open(NameDB)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer file.Close()
	var res string
	b, _ := os.ReadFile(NameDB)
	res = string(b)
	var lines = strings.Split(res, "\n")
	for i := 0; i < len(lines); i++ {
		var s = strings.Split(lines[i], " ")
		if len(s) != 5 {
			continue
		}
		if s[2] == login {
			return true
		}
	}
	return false
}
func findPerson(login, password string) Answer {
	file, err := os.Open(NameDB)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer file.Close()

	var res string
	b, _ := os.ReadFile(NameDB)
	res = string(b)
	var lines = strings.Split(res, "\n")
	for i := 0; i < len(lines); i++ {
		var s = strings.Split(lines[i], " ")
		if len(s) != 5 {
			continue
		}
		if s[2] == login {
			if s[3] == password {
				return Answer{Person{s[0], s[1], s[2], s[3], s[4]}, true}
			} else {
				fmt.Println("Пароль неверен")
				return Answer{Person{}, false}
			}
		}
	}
	return Answer{Person{}, false}
}
func auth() {
	if Auth {
		fmt.Println("Вы авторизованы")
		return
	}
	var login, password string
	fmt.Println("Введите логин")
	fmt.Scan(&login)
	fmt.Println("Введите пароль")
	fmt.Scan(&password)
	var res = findPerson(login, password)
	if res.code {
		fmt.Println("Успешно авторизован " + res.person.SName + " " + res.person.FName + "!")
		Auth = true
		User = res.person
	} else {
		fmt.Println("Авторизируйтесь заново")
	}
}
func menu() bool {
	fmt.Println("---------------------")
	fmt.Println(strconv.Itoa(1) + " Авторизация")
	fmt.Println(strconv.Itoa(2) + " Регистрация")
	fmt.Println(strconv.Itoa(3) + " Обо мне")
	fmt.Println(strconv.Itoa(4) + " Выход")
	fmt.Println("---------------------")
	var ii int
	fmt.Fscan(os.Stdin, &ii)
	switch ii {
	case 1:
		auth()
		return true
	case 2:
		person := createPerson()
		writePerson(person)
		return true
	case 3:
		about()
		return true
	case 4:
		return false
	default:
		return true
	}

}
func about() {
	if Auth {
		fmt.Println("Фамилия: " + User.SName + "\nИмя: " + User.FName + "\nЛогин: " + User.login + "\nПароль: " + User.password + "\nРоль: " + User.role)
	} else {
		fmt.Println("Авторизируйтесь")
		auth()
	}
}
func writePerson(per Person) {
	file, err := os.OpenFile(NameDB, os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println("Unable to create file:", err)
		os.Exit(1)
	}
	defer file.Close()
	if _, err = file.WriteString(per.FName + " " + per.SName + " " + per.login + " " + per.password + " " + per.role + "\n"); err != nil {
		panic(err)
	}

	/*_, err = file.WriteString(per.FName + " " + per.SName + " " + per.login + " " + per.password + " " + per.role + "\n")
	if err != nil {
		return
	}*/

}
*/